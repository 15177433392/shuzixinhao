function varargout = jj(varargin)
%JJ M-file for jj.fig
%      JJ, by itself, creates a new JJ or raises the existing
%      singleton*.
%
%      H = JJ returns the handle to a new JJ or the handle to
%      the existing singleton*.
%
%      JJ('Property','Value',...) creates a new JJ using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to jj_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      JJ('CALLBACK') and JJ('CALLBACK',hObject,...) call the
%      local function named CALLBACK in JJ.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help jj

% Last Modified by GUIDE v2.5 10-Aug-2021 13:36:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @jj_OpeningFcn, ...
    'gui_OutputFcn',  @jj_OutputFcn, ...
    'gui_LayoutFcn',  [], ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before jj is made visible.
function jj_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)
set(gcf,'name','��ϵ΢�ţ�matlab2022   ');
msgbox('δ�����֣���+΢�ţ�matlab2022 ');
return
% Choose default command line output for jj
handles.output = hObject;
Nx=20;
Nh=10;
n=0:Nx-1;
x=(0.9).^n;
axes(handles.axes1);
handles.axes1=stem(n,x,'.');title('x=0.9^n','FontSize',16);
grid on;
axes(handles.axes2);
handles.axes2=stem(nh,h,'r.');title('h=u(n)-u(n-5)','FontSize',16);axis([-3 13 0 1.2])
grid on;
axes(handles.axes3);
handles.axes3=stem(m,y,'.');title('y=x*h','FontSize',16);
grid on;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes jj wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = jj_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2
